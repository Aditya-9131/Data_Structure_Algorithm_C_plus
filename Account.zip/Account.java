import java.util.ArrayList;
import java.util.Scanner;

class Account {
    private int accountNumber;
    private String accountType;
    private String serviceBranchIFSC;
    private float minimumBalance;
    private float availableBalance;
    private int customerID;
    private String customerName;
    private static int totalAccountCreated = 0;

    // Constructor
    public Account() {
        totalAccountCreated++;
    }

    // Setter method for details
    public void setDetails() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Account Number: ");
        accountNumber = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Account Type: ");
        accountType = scanner.nextLine();
        System.out.print("Enter Service Branch IFSC: ");
        serviceBranchIFSC = scanner.nextLine();
        System.out.print("Enter Minimum Balance: ");
        minimumBalance = scanner.nextFloat();
        availableBalance = minimumBalance; // Initially, available balance equals minimum balance
        System.out.print("Enter Customer ID: ");
        customerID = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Customer Name: ");
        customerName = scanner.nextLine();
    }

    // Getter method for account details
    public String getDetails(int accountNo) {
        if (accountNumber == accountNo) {
            return "Account Number: " + accountNumber +
                    "\nAccount Type: " + accountType +
                    "\nService Branch IFSC: " + serviceBranchIFSC +
                    "\nMinimum Balance: " + minimumBalance +
                    "\nAvailable Balance: " + availableBalance +
                    "\nCustomer ID: " + customerID +
                    "\nCustomer Name: " + customerName;
        } else {
            return "Account not found!";
        }
    }

    // Update account details
    public void updateDetails(int accountNo) {
        if (accountNumber == accountNo) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter New Account Type: ");
            accountType = scanner.nextLine();
            System.out.print("Enter New Service Branch IFSC: ");
            serviceBranchIFSC = scanner.nextLine();
            System.out.print("Enter New Customer ID: ");
            customerID = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter New Customer Name: ");
            customerName = scanner.nextLine();
        } else {
            System.out.println("Account not found!");
        }
    }

    // Get account balance
    public float getBalance(int accountNo) {
        if (accountNumber == accountNo) {
            return availableBalance;
        } else {
            return -1; // Account not found
        }
    }

    // Deposit money into the account
    public void deposit(int accountNo, float amount) {
        if (accountNumber == accountNo) {
            if (amount > 0) {
                availableBalance += amount;
                System.out.println("Deposit successful. Updated balance: " + availableBalance);
            } else {
                System.out.println("Invalid deposit amount.");
            }
        } else {
            System.out.println("Account not found!");
        }
    }

    // Withdraw money from the account
    public void withdraw(int accountNo, float amount) {
        if (accountNumber == accountNo) {
            if (amount > 0 && availableBalance - amount >= minimumBalance) {
                availableBalance -= amount;
                System.out.println("Withdrawal successful. Updated balance: " + availableBalance);
            } else {
                System.out.println("Invalid withdrawal amount or insufficient balance.");
            }
        } else {
            System.out.println("Account not found!");
        }
    }

    // Static method to get total accounts created
    public static int totalAccount() {
        return totalAccountCreated;
    }

    // Static method to compare two accounts
    public static int compare(Account account1, Account account2) {
        if (account1.availableBalance < account2.availableBalance) {
            return -1;
        } else if (account1.availableBalance > account2.availableBalance) {
            return 1;
        } else {
            return 0;
        }
    }
}

public class BankingApplication {
    public static void main(String[] args) {
        ArrayList<Account> accounts = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nBanking Application Menu:");
            System.out.println("1. Create a new account");
            System.out.println("2. Delete an account (Not implemented in this example)");
            System.out.println("3. Modify details of an account");
            System.out.println("4. Check account balance");
            System.out.println("5. Deposit money");
            System.out.println("6. Withdraw money");
            System.out.println("7. Total accounts created");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    Account newAccount = new Account();
                    newAccount.setDetails();
                    accounts.add(newAccount);
                    System.out.println("Account created successfully!");
                    break;
                case 2:
                    System.out.println("Account deletion is not implemented in this example.");
                    break;
                case 3:
                    System.out.print("Enter Account Number to modify: ");
                    int accountNo = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    for (Account account : accounts) {
                        account.updateDetails(accountNo);
                    }
                    break;
                case 4:
                    System.out.print("Enter Account Number to check balance: ");
                    accountNo = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    for (Account account : accounts) {
                        float balance = account.getBalance(accountNo);
                        if (balance != -1) {
                            System.out.println("Account Balance: " + balance);
                        } else {
                            System.out.println("Account not found!");
                        }
                    }
                    break;
                case 5:
                    System.out.print("Enter Account Number to deposit: ");
                    accountNo = scanner.nextInt();
                    System.out.print("Enter deposit amount: ");
                    float depositAmount = scanner.nextFloat();
                    scanner.nextLine(); // Consume newline
                    for (Account account : accounts) {
                        account.deposit(accountNo, depositAmount);
                    }
                    break;
                case 6:
                    System.out.print("Enter Account Number to withdraw: ");
                    accountNo = scanner.nextInt();
                    System.out.print("Enter withdrawal amount: ");
                    float withdrawalAmount = scanner.nextFloat();
                    scanner.nextLine(); // Consume newline
                    for (Account account : accounts) {
                        account.withdraw(accountNo, withdrawalAmount);
                    }
                    break;
                case 7:
                    System.out.println("Total accounts created: " + Account.totalAccount());
                    break;
                case 8:
                    System.out.println("Exiting the application. Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }
}
